<script setup>
    import NewDisque from 'principalC/NewDisque.vue'
</script>
<template>
    <NewDisque/>
</template>
<style>
    
</style>