<script setup>
    import TransfertLaptop from 'principalC/TransfertLaptop.vue'
</script>
<template>
    <TransfertLaptop/>
</template>
<style scoped>
</style>