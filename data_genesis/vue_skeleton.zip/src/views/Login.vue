<script setup>
    import Login from 'principalC/Login.vue';
</script>
<template>
    <Login/>
</template>
<style>
    
</style>