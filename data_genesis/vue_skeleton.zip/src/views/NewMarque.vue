<script setup>
    import  NewMarque  from 'principalC/NewMarque.vue'
</script>
<template>
    <NewMarque/>
</template>
<style>
    
</style>