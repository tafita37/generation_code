<script setup>
    import NewUtilisateur from 'principalC/NewUtilisateur.vue'
</script>
<template>
    <NewUtilisateur/>
</template>
<style scoped>
</style>