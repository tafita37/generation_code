<script setup>
    import NewLaptop from 'principalC/NewLaptop.vue'
</script>
<template>
    <NewLaptop/>
</template>
<style>
    
</style>