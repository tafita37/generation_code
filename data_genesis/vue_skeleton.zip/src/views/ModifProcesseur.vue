<script setup>
    import ModifProcesseur from 'principalC/ModifProcesseur.vue'
</script>
<template>
    <ModifProcesseur/>
</template>
<style scoped>
</style>