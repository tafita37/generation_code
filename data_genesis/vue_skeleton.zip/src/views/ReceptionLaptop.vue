<script setup>
    import ReceptionLaptop from 'principalC/ReceptionLaptop.vue'
</script>
<template>
    <ReceptionLaptop/>
</template>
<style scoped>
</style>