<script setup>
    import ModifMarque from 'principalC/ModifMarque.vue'
</script>
<template>
    <ModifMarque/>
</template>
<style scoped>
</style>