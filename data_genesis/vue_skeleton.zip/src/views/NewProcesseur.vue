<script setup>
    import  NewProcesseur  from 'principalC/NewProcesseur.vue'
</script>
<template>
    <NewProcesseur/>
</template>
<style>
    
</style>