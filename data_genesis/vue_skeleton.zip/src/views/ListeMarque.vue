<script setup>
    import ListeMarque from 'principalC/ListeMarque.vue'
</script>
<template>
    <ListeMarque/>
</template>
<style scoped>
</style>