<script setup>
    import ModifRam from 'principalC/ModifRam.vue'
</script>
<template>
    <ModifRam/>
</template>
<style scoped>
</style>