<script setup>
    import ListeProcesseur from 'principalC/ListeProcesseur.vue'
</script>
<template>
    <ListeProcesseur/>
</template>
<style scoped>
</style>