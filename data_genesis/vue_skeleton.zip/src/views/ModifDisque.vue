<script setup>
    import ModifDisque from 'principalC/ModifDisque.vue'
</script>
<template>
    <ModifDisque/>
</template>
<style scoped>
</style>