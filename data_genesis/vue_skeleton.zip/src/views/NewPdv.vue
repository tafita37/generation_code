<script setup>
    import  NewPdv  from 'principalC/NewPdv.vue'
</script>
<template>
    <NewPdv/>
</template>
<style>
    
</style>