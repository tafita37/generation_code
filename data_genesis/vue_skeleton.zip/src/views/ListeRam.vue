<script setup>
    import ListeRam from 'principalC/ListeRam.vue'
</script>
<template>
    <ListeRam/>
</template>
<style scoped>
</style>