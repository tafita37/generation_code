<script setup>
    import ListeDisque from 'principalC/ListeDisque.vue'
</script>
<template>
    <ListeDisque/>
</template>
<style scoped>
</style>