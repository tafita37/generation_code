<script setup>
    import AjoutStock from 'principalC/AjoutStock.vue'
</script>
<template>
    <AjoutStock/>
</template>
<style scoped>
</style>