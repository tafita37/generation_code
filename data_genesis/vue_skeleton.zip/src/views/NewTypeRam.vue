<script setup>
    import  NewTypeRam  from 'principalC/NewTypeRam.vue'
</script>
<template>
    <NewTypeRam/>
</template>
<style>
    
</style>