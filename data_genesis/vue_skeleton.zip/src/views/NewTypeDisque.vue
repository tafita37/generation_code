<script setup>
    import  NewTypeDisque  from 'principalC/NewTypeDisque.vue'
</script>
<template>
    <NewTypeDisque/>
</template>
<style>
    
</style>