<script setup>
    import LoginPointVente from 'principalC/LoginPointVente.vue';
</script>
<template>
    <LoginPointVente/>
</template>
<style>
    
</style>