<script setup>
    import ModifLaptop from 'principalC/ModifLaptop.vue'
</script>
<template>
    <ModifLaptop/>
</template>
<style scoped>
</style>