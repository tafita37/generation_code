<script setup>
    import  NewRam  from 'principalC/NewRam.vue'
</script>
<template>
    <NewRam/>
</template>
<style>
    
</style>