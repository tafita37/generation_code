<script setup>
    import ListeLaptop from 'principalC/ListeLaptop.vue'
</script>
<template>
    <ListeLaptop/>
</template>
<style scoped>
</style>