<script setup>
    import VenteLaptop from 'principalC/VenteLaptop.vue'
</script>
<template>
    <VenteLaptop/>
</template>
<style scoped>
</style>