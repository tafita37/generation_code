<script setup>
    import  NewPdvUser  from 'principalC/NewPdvUser.vue'
</script>
<template>
    <NewPdvUser/>
</template>
<style>
    
</style>