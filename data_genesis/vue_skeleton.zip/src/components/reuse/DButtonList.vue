<script setup>
</script>
<template>
    <div class="button_list">
        <slot></slot>
    </div>
</template>
<style scoped>
    .button_list {
        display: flex;
        flex-direction: column;
    }
</style>